# PDF Embed & SEO Optimize for Drupal

<p align="center">
  <img src="https://pdfviewer.drossmedia.de/wp-content/uploads/2025/03/wp-pdf-embed-and-seo-optimized.png" alt="PDF Embed & SEO Optimize" width="128">
</p>

A powerful Drupal module that integrates Mozilla's PDF.js viewer to display PDFs with clean URLs, SEO optimization, and access controls.

**Current Version:** 1.2.9
**Platforms:** Drupal 10, Drupal 11
**License:** GPL v2 or later
**Website:** [pdfviewer.drossmedia.de](https://pdfviewer.drossmedia.de)

## Free vs Premium

This module comes in two parts:
- **pdf_embed_seo** (Free) - Core PDF viewing functionality
- **pdf_embed_seo_premium** (Premium) - Advanced features like analytics, password protection, and reading progress

Get premium at: **https://pdfviewer.drossmedia.de**

---

## Feature Comparison

| Feature | Free | Premium |
|---------|:----:|:-------:|
| **Viewer & Display** | | |
| Mozilla PDF.js Viewer | ✓ | ✓ |
| Light Theme | ✓ | ✓ |
| Dark Theme | ✓ | ✓ |
| Responsive Design | ✓ | ✓ |
| Print Control (per PDF) | ✓ | ✓ |
| Download Control (per PDF) | ✓ | ✓ |
| Configurable Viewer Height | ✓ | ✓ |
| PDF Viewer Block | ✓ | ✓ |
| **Content Management** | | |
| PDF Document Entity | ✓ | ✓ |
| Title, Description, Slug Fields | ✓ | ✓ |
| File Upload & Management | ✓ | ✓ |
| Thumbnail Support | ✓ | ✓ |
| Auto-Generate Thumbnails | ✓ | ✓ |
| Published/Unpublished Status | ✓ | ✓ |
| Owner/User Tracking | ✓ | ✓ |
| Multi-language Support | ✓ | ✓ |
| Admin List with Columns | ✓ | ✓ |
| **SEO & URLs** | | |
| Clean URL Structure (`/pdf/slug/`) | ✓ | ✓ |
| Auto Path Alias Generation | ✓ | ✓ |
| Schema.org Markup (DigitalDocument) | ✓ | ✓ |
| Archive Schema (CollectionPage) | ✓ | ✓ |
| **Archive & Listing** | | |
| Archive Page (`/pdf`) | ✓ | ✓ |
| Pagination Support | ✓ | ✓ |
| Grid/List Display Modes | ✓ | ✓ |
| Sorting Options | ✓ | ✓ |
| Search Filtering | ✓ | ✓ |
| **REST API** | | |
| GET /documents (list) | ✓ | ✓ |
| GET /documents/{id} (single) | ✓ | ✓ |
| GET /documents/{id}/data (secure URL) | ✓ | ✓ |
| POST /documents/{id}/view (track) | ✓ | ✓ |
| GET /settings | ✓ | ✓ |
| **Statistics** | | |
| Basic View Counter | ✓ | ✓ |
| View Count Display | ✓ | ✓ |
| **Security** | | |
| Nonce/CSRF Protection | ✓ | ✓ |
| Permission System | ✓ | ✓ |
| Entity Access Control | ✓ | ✓ |
| Secure PDF URL (no direct links) | ✓ | ✓ |
| **Theming** | | |
| Twig Template Overrides | ✓ | ✓ |
| CSS Classes for Styling | ✓ | ✓ |
| **Developer** | | |
| Drupal Hooks (alter, events) | ✓ | ✓ |
| Cache Tags & Contexts | ✓ | ✓ |
| **Premium Features** | | |
| Analytics Dashboard | - | ✓ |
| Detailed View Tracking (IP, UA, referrer) | - | ✓ |
| Popular Documents Report | - | ✓ |
| Recent Views Log | - | ✓ |
| Analytics Export (CSV/JSON) | - | ✓ |
| Password Protection | - | ✓ |
| Password Verification API | - | ✓ |
| Reading Progress Tracking | - | ✓ |
| Resume Reading Feature | - | ✓ |
| Download Tracking | - | ✓ |
| Expiring Access Links | - | ✓ |
| Role-Based Access Control | - | ✓ |
| AI Schema Optimization (GEO/AEO/LLM) | - | ✓ |
| Bulk Import (CSV) | - | ✓ |
| Text Search in Viewer | - | ✓ |
| Bookmarks Navigation | - | ✓ |
| XML Sitemap (`/pdf/sitemap.xml`) | - | ✓ |
| Sitemap XSL Stylesheet | - | ✓ |
| 14+ Premium REST API Endpoints | - | ✓ |

---

## Requirements

- Drupal 10 or 11
- PHP 8.1 or higher
- ImageMagick or Ghostscript (optional, for thumbnail generation)

## Installation

1. Download the module to your Drupal site's `modules` directory
2. Enable the module via Drush: `drush en pdf_embed_seo`
3. Or enable via the admin UI: Admin > Extend > PDF Embed & SEO Optimize
4. Configure settings at Admin > Configuration > Content > PDF Embed & SEO

## Configuration

### General Settings
- **Default Allow Download**: Whether new PDFs allow downloads by default
- **Default Allow Print**: Whether new PDFs allow printing by default
- **Auto-generate Thumbnails**: Automatically create thumbnails from PDF first pages

### Privacy & GDPR Settings
- **IP Anonymization**: Anonymizes IP addresses stored in analytics data for GDPR compliance (enabled by default)
  - IPv4: Zeros the last octet (e.g., `192.168.1.123` → `192.168.1.0`)
  - IPv6: Zeros the last 80 bits (keeps first 48 bits)

### Viewer Settings
- **Viewer Theme**: Choose between light and dark themes
- **Viewer Height**: Default height for the PDF viewer

### Archive Settings
- **Documents Per Page**: Number of PDFs to show on the archive page
- **Display Mode**: Grid or list layout
- **Content Alignment**: Left, center, or right alignment for archive content
- **Font Color**: Custom font color for archive items
- **Background Color**: Custom background color for archive area
- **Layout Width**: Boxed or full-width layout

## Usage

### Adding PDF Documents
1. Go to Admin > Content > PDF Documents
2. Click "Add PDF Document"
3. Fill in the title and description
4. Upload your PDF file
5. Configure print/download permissions
6. Save

### Embedding PDFs with Block
Use the PDF Viewer block to embed PDFs in any region:
1. Go to Admin > Structure > Block Layout
2. Place a new "PDF Viewer" block
3. Select the PDF document to display
4. Configure height and title visibility

### URL Structure
| Page | URL |
|------|-----|
| Archive | `/pdf` |
| Single PDF | `/pdf/{slug}` |
| XML Sitemap (Premium) | `/pdf/sitemap.xml` |
| Admin List | `/admin/content/pdf-documents` |
| Settings | `/admin/config/content/pdf-embed-seo` |
| Analytics (Premium) | `/admin/reports/pdf-analytics` |

---

## Permissions

### Free Permissions
| Permission | Description |
|------------|-------------|
| Administer PDF Embed & SEO settings | Configure module settings |
| Access PDF document overview | View the admin list of PDFs |
| View PDF documents | View published PDFs on the frontend |
| Create PDF documents | Create new PDF documents |
| Edit PDF documents | Edit any PDF document |
| Edit own PDF documents | Edit only your own PDF documents |
| Delete PDF documents | Delete any PDF document |
| Delete own PDF documents | Delete only your own PDF documents |

### Premium Permissions
| Permission | Description |
|------------|-------------|
| View PDF analytics | Access the analytics dashboard |
| Export PDF analytics | Export analytics data to CSV/JSON |
| Bypass PDF password protection | View protected PDFs without password |
| Download protected PDFs | Download PDFs when disabled for others |
| Administer PDF Premium settings | Configure premium settings |

---

## Theming

### Template Files
Override these templates in your theme:
| Template | Description |
|----------|-------------|
| `pdf-document.html.twig` | Single PDF document display |
| `pdf-viewer.html.twig` | The PDF.js viewer |
| `pdf-archive.html.twig` | Archive page listing |
| `pdf-archive-item.html.twig` | Individual archive item |

### CSS Classes
| Class | Description |
|-------|-------------|
| `.pdf-viewer-wrapper` | Main viewer container |
| `.pdf-viewer-toolbar` | Toolbar with controls |
| `.pdf-viewer-container` | Canvas container |
| `.pdf-viewer-theme-light` | Light theme modifier |
| `.pdf-viewer-theme-dark` | Dark theme modifier |
| `.pdf-archive` | Archive page wrapper |
| `.pdf-archive-item` | Individual archive item |
| `.pdf-download-button` | Download button |

---

## REST API

### API Base URL
```
/api/pdf-embed-seo/v1/
```

### Free Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/documents` | List all published PDF documents |
| `GET` | `/documents/{id}` | Get single PDF document details |
| `GET` | `/documents/{id}/data` | Get PDF file URL securely |
| `POST` | `/documents/{id}/view` | Track a PDF view |
| `GET` | `/settings` | Get public module settings |

### Premium Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/analytics` | Get analytics overview |
| `GET` | `/analytics/documents` | Per-document analytics |
| `GET` | `/analytics/export` | Export analytics CSV/JSON |
| `GET` | `/documents/{id}/progress` | Get reading progress |
| `POST` | `/documents/{id}/progress` | Save reading progress |
| `POST` | `/documents/{id}/verify-password` | Verify PDF password |
| `POST` | `/documents/{id}/download` | Track PDF download |
| `POST` | `/documents/{id}/expiring-link` | Generate expiring link |
| `GET` | `/documents/{id}/expiring-link/{token}` | Validate expiring link |
| `GET` | `/categories` | List PDF categories |
| `GET` | `/tags` | List PDF tags |
| `POST` | `/bulk/import` | Start bulk import |
| `GET` | `/bulk/import/{id}/status` | Get import status |

### Query Parameters for /documents

| Parameter | Default | Description |
|-----------|---------|-------------|
| `page` | 0 | Page offset for pagination |
| `limit` | 50 | Items per page (max 100) |
| `sort` | created | Sort by: created, title, view_count |
| `direction` | DESC | Sort direction: ASC or DESC |

### Example Response
```json
{
  "id": 123,
  "title": "Annual Report 2024",
  "slug": "annual-report-2024",
  "url": "https://example.com/pdf/annual-report-2024",
  "description": "Company annual report...",
  "created": "2024-01-15T10:30:00+00:00",
  "modified": "2024-06-20T14:45:00+00:00",
  "views": 1542,
  "thumbnail": "https://example.com/sites/default/files/thumbnails/report.jpg",
  "allow_download": true,
  "allow_print": false
}
```

---

## Drupal Hooks

### Alter Hooks

| Hook | Description |
|------|-------------|
| `hook_pdf_embed_seo_document_data_alter` | Modify PDF data returned by API |
| `hook_pdf_embed_seo_api_settings_alter` | Modify API settings response |
| `hook_pdf_embed_seo_schema_alter` | Modify Schema.org output |

### Event Hooks

| Hook | Description |
|------|-------------|
| `hook_pdf_embed_seo_view_tracked` | Fired when a PDF view is tracked |

### Premium Hooks

| Hook | Description |
|------|-------------|
| `hook_pdf_embed_seo_verify_password_alter` | Override password verification |

### Example: Modify Document Data
```php
/**
 * Implements hook_pdf_embed_seo_document_data_alter().
 */
function mymodule_pdf_embed_seo_document_data_alter(array &$data, $document) {
  $data['department'] = $document->get('field_department')->value;
}
```

### Example: Modify API Settings
```php
/**
 * Implements hook_pdf_embed_seo_api_settings_alter().
 */
function mymodule_pdf_embed_seo_api_settings_alter(array &$settings) {
  // Add custom settings to API response
  $settings['custom_branding'] = 'My Company';
}
```

### Example: Custom Schema Data
```php
/**
 * Implements hook_pdf_embed_seo_schema_alter().
 */
function mymodule_pdf_embed_seo_schema_alter(array &$schema, $document) {
  $schema['author'] = [
    '@type' => 'Person',
    'name' => $document->get('field_author')->value,
  ];
}
```

### Example: React to View Tracking
```php
/**
 * Implements hook_pdf_embed_seo_view_tracked().
 */
function mymodule_pdf_embed_seo_view_tracked($pdf_document, $view_count) {
  // Log popular documents or trigger notifications
  if ($view_count == 1000) {
    \Drupal::logger('mymodule')->notice('Document @title reached 1000 views!', [
      '@title' => $pdf_document->label(),
    ]);
  }
}
```

### Example: Custom Password Verification (Premium)
```php
/**
 * Implements hook_pdf_embed_seo_verify_password_alter().
 */
function mymodule_pdf_embed_seo_verify_password_alter(&$is_valid, $pdf_document, $password) {
  // Implement custom password logic (e.g., LDAP, external API)
  if ($password === 'master-key') {
    $is_valid = TRUE;
  }
}
```

---

## JavaScript Events

The PDF viewer triggers these JavaScript events:

| Event | Description |
|-------|-------------|
| `pdfLoaded` | When PDF document is loaded |
| `pageRendered` | When a page is rendered |
| `pageChanged` | When user navigates to a different page |
| `zoomChanged` | When zoom level changes |

---

## Services

| Service | Description |
|---------|-------------|
| `pdf_embed_seo.thumbnail_generator` | Generate PDF thumbnails |

### Premium Services

| Service | Description |
|---------|-------------|
| `pdf_embed_seo.analytics_tracker` | Track and query view statistics |
| `pdf_embed_seo.progress_tracker` | Save and retrieve reading progress |
| `pdf_embed_seo.schema_enhancer` | GEO/AEO/LLM schema optimization |
| `pdf_embed_seo.access_manager` | Role-based access control |
| `pdf_embed_seo.viewer_enhancer` | Enhanced viewer features |
| `pdf_embed_seo.bulk_operations` | Bulk import and update operations |

---

## Changelog

### 1.2.9
- **Performance Improvements**
  - Removed entity saves during page views - views now tracked directly in analytics table
  - Added cache tag invalidation for lists via entity insert/update/delete hooks
  - Added cache metadata to PdfViewerBlock with tags, contexts, and max-age
- **Security & Privacy**
  - Fixed Pathauto service dependency with graceful fallback
  - Added IP anonymization setting for GDPR compliance (enabled by default)
- **Bug Fixes**
  - Archive page list view icon alignment fix
  - Boxed layout fix for grid and list views

### 1.2.8
- Archive Settings improvements
  - Renamed "Heading Alignment" to "Content Alignment" with updated help text
  - Content alignment now applies to entire archive page (header, list, and grid)
  - Font color and background color settings now apply to content items
  - Added Content Alignment, Font Color, and Background Color settings
- Grid/List view styling enhancements
  - Font color setting now applies to grid card titles, excerpts, and metadata
  - Item background color setting now applies to individual grid cards
  - List view inherits font color for links and titles
- Seamless background color coverage fix

### 1.2.7
- Sidebar/Widget Area Removal - PDF pages now display full-width without sidebars
  - Added `hook_theme_suggestions_page_alter()` for full-width page templates
  - Added `hook_preprocess_page()` to clear sidebar regions on PDF routes
  - Added `hook_preprocess_html()` to add `.page-pdf` body classes for CSS targeting
  - Added CSS rules to hide common sidebar selectors

### 1.2.6
- Security fixes
  - Implemented proper password hashing using Drupal's password service
  - Fixed XSS vulnerability in PdfViewerBlock with proper HTML escaping

### 1.2.5
- Download Tracking - Track PDF downloads separately from views
- Expiring Access Links - Generate time-limited URLs with max usage limits
- Drupal Premium feature parity with WordPress:
  - PdfSchemaEnhancer service for GEO/AEO/LLM optimization
  - PdfAccessManager service for role-based access control
  - PdfBulkOperations service for CSV import and bulk updates
  - PdfViewerEnhancer service for text search, bookmarks, reading progress UI
- Extended REST API with 14+ premium endpoints matching WordPress
- New endpoints: `/download`, `/expiring-link`, `/categories`, `/tags`, `/bulk/import`

### 1.2.4
- Premium AI & Schema Optimization for GEO/AEO/LLM
- AI Summary, FAQ Schema, Table of Contents, Reading Time fields

### 1.2.1
- Version bump for release
- Documentation improvements

### 1.2.0
- Added REST API endpoints for external integrations
- Added reading progress tracking (Premium)
- Added password verification endpoint (Premium)
- Added XML sitemap at /pdf/sitemap.xml (Premium)
- Added Drupal hooks for extensibility
- Separated free and premium into base module + submodule
- Improved API documentation

### 1.1.5
- Version sync with WordPress plugin
- Bug fixes and improvements

### 1.0.0
- Initial release
- Custom entity type for PDF documents
- PDF.js viewer integration
- SEO optimization with Schema.org
- Print/download controls
- View statistics
- Block plugin
- Archive page

---

## License

GPL v2 or later - https://www.gnu.org/licenses/gpl-2.0.html

## Credits

Made with ♥ by [Dross:Media](https://dross.net/media/)
