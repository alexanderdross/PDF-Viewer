<?php

namespace Drupal\pdf_embed_seo\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Url;
use Drupal\pdf_embed_seo\Entity\PdfDocumentInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Controller for viewing individual PDF documents.
 */
class PdfViewController extends ControllerBase {

  /**
   * Constructs a PdfViewController.
   *
   * @param \Drupal\Core\Extension\ModuleExtensionList $moduleExtensionList
   *   The module extension list.
   * @param \Symfony\Component\HttpFoundation\RequestStack $requestStack
   *   The request stack.
   */
  public function __construct(
    protected ModuleExtensionList $moduleExtensionList,
    protected RequestStack $requestStack,
  ) {
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
          $container->get('extension.list.module'),
          $container->get('request_stack'),
      );
  }

  /**
   * View a PDF document.
   *
   * @param \Drupal\pdf_embed_seo\Entity\PdfDocumentInterface $pdf_document
   *   The PDF document entity.
   *
   * @return array
   *   A render array.
   */
  public function view(PdfDocumentInterface $pdf_document): array {
    // Check if document is published.
    if (!$pdf_document->isPublished() && !$this->currentUser()->hasPermission('administer pdf embed seo')) {
      throw new NotFoundHttpException();
    }

    // Determine cache contexts - add 'session' for password-protected PDFs.
    $cache_contexts = ['user.permissions'];
    $is_password_protected = $pdf_document->hasPassword();

    if ($is_password_protected) {
      // Add session context so password unlock state is properly cached per session.
      $cache_contexts[] = 'session';
    }

    // Check for password protection (premium feature).
    if ($is_password_protected && !$this->isPasswordUnlocked($pdf_document)) {
      return $this->passwordForm($pdf_document, $cache_contexts);
    }

    $config = $this->config('pdf_embed_seo.settings');

    // Get viewer settings.
    $allow_download = $pdf_document->allowsDownload();
    $allow_print = $pdf_document->allowsPrint();
    $viewer_theme = $config->get('viewer_theme') ?? 'light';
    $viewer_height = $config->get('viewer_height') ?? '800px';

    // Determine Pro+ status and settings.
    $is_pro_plus = $this->moduleHandler()->moduleExists('pdf_embed_seo_pro_plus')
      && function_exists('pdf_embed_seo_pro_plus_is_valid')
      && pdf_embed_seo_pro_plus_is_valid();
    $pro_plus_settings = $is_pro_plus && function_exists('pdf_embed_seo_pro_plus_get_settings')
      ? pdf_embed_seo_pro_plus_get_settings()
      : [];

    // Build the render array.
    $build = [
      '#theme' => 'pdf_viewer',
      '#pdf_document' => $pdf_document,
      '#pdf_url' => $this->getPdfDataUrl($pdf_document),
      '#allow_download' => $allow_download,
      '#allow_print' => $allow_print,
      '#viewer_theme' => $viewer_theme,
      '#height' => $viewer_height,
      '#is_pro_plus' => $is_pro_plus,
      '#enable_annotations' => !empty($pro_plus_settings['enable_annotations']),
      '#enable_versioning' => !empty($pro_plus_settings['enable_versioning']),
      '#enable_advanced_analytics' => !empty($pro_plus_settings['enable_advanced_analytics']),
      '#enable_compliance' => !empty($pro_plus_settings['enable_compliance']),
      '#attached' => [
        'library' => [
          'pdf_embed_seo/viewer',
        ],
        'drupalSettings' => [
          'pdfEmbedSeo' => [
            'pdfUrl' => $this->getPdfDataUrl($pdf_document),
            'workerSrc' => '/' . $this->moduleExtensionList->getPath('pdf_embed_seo') . '/assets/pdfjs/pdf.worker.min.js',
            'allowDownload' => $allow_download,
            'allowPrint' => $allow_print,
            'documentId' => $pdf_document->id(),
            'documentTitle' => $pdf_document->label(),
            'isProPlus' => $is_pro_plus,
          ],
        ],
      ],
      '#cache' => [
        'tags' => $pdf_document->getCacheTags(),
        'contexts' => $cache_contexts,
      ],
    ];

    // Add dark theme library if configured.
    if ($viewer_theme === 'dark') {
      $build['#attached']['library'][] = 'pdf_embed_seo/viewer-dark';
    }

    // Add premium features if available.
    if ($this->moduleHandler()->moduleExists('pdf_embed_seo_premium')) {
      if ($config->get('enable_search')) {
        $build['#attached']['library'][] = 'pdf_embed_seo/premium-search';
      }
      if ($config->get('enable_bookmarks')) {
        $build['#attached']['library'][] = 'pdf_embed_seo/premium-bookmarks';
      }
      if ($config->get('enable_progress')) {
        $build['#attached']['library'][] = 'pdf_embed_seo/premium-progress';
      }
      if ($config->get('enable_analytics')) {
        $build['#attached']['library'][] = 'pdf_embed_seo/premium-analytics';
      }
    }

    // Add Pro+ Enterprise features if available.
    if ($is_pro_plus) {
      $build['#attached']['library'][] = 'pdf_embed_seo/pro-plus-toolbar';
      if (!empty($pro_plus_settings['enable_annotations'])) {
        $build['#attached']['library'][] = 'pdf_embed_seo/pro-plus-annotations';
      }
    }

    return $build;
  }

  /**
   * Get the title for a PDF document.
   *
   * @param \Drupal\pdf_embed_seo\Entity\PdfDocumentInterface $pdf_document
   *   The PDF document entity.
   *
   * @return string
   *   The title.
   */
  public function title(PdfDocumentInterface $pdf_document): string {
    return $pdf_document->label();
  }

  /**
   * Display password form for protected PDF.
   *
   * @param \Drupal\pdf_embed_seo\Entity\PdfDocumentInterface $pdf_document
   *   The PDF document entity.
   * @param array $cache_contexts
   *   Cache contexts to apply.
   *
   * @return array
   *   A render array.
   */
  protected function passwordForm(PdfDocumentInterface $pdf_document, array $cache_contexts = []): array {
    $form = $this->formBuilder()->getForm('Drupal\pdf_embed_seo\Form\PdfPasswordForm', $pdf_document);

    // Default cache contexts if not provided.
    if (empty($cache_contexts)) {
      $cache_contexts = ['user.permissions', 'session'];
    }

    return [
      '#theme' => 'pdf_password_form',
      '#pdf_document' => $pdf_document,
      '#form' => $form,
      '#attached' => [
        'library' => ['pdf_embed_seo/premium-password'],
      ],
      '#cache' => [
        'tags' => $pdf_document->getCacheTags(),
        'contexts' => $cache_contexts,
      // Don't cache password forms to ensure fresh session checks.
        'max-age' => 0,
      ],
    ];
  }

  /**
   * Check if the PDF password has been unlocked for current session.
   *
   * @param \Drupal\pdf_embed_seo\Entity\PdfDocumentInterface $pdf_document
   *   The PDF document entity.
   *
   * @return bool
   *   TRUE if unlocked, FALSE otherwise.
   */
  protected function isPasswordUnlocked(PdfDocumentInterface $pdf_document): bool {
    // Admins can bypass password.
    if ($this->currentUser()->hasPermission('bypass pdf password')) {
      return TRUE;
    }

    $request = $this->requestStack->getCurrentRequest();
    if (!$request || !$request->hasSession()) {
      return FALSE;
    }

    $session = $request->getSession();
    $unlocked = $session->get('pdf_unlocked', []);

    return in_array($pdf_document->id(), $unlocked, TRUE);
  }

  /**
   * Get the PDF data URL for AJAX loading.
   *
   * @param \Drupal\pdf_embed_seo\Entity\PdfDocumentInterface $pdf_document
   *   The PDF document entity.
   *
   * @return string
   *   The URL to the PDF data endpoint.
   */
  protected function getPdfDataUrl(PdfDocumentInterface $pdf_document): string {
    return Url::fromRoute(
          'pdf_embed_seo.pdf_data', [
            'pdf_document' => $pdf_document->id(),
          ]
      )->toString();
  }

}
